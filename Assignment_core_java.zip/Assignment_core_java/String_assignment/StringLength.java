
public class StringLength {

	public static void main(String[] args) {
		String str="Hello World";
		int s1=str.length();
		System.out.println("The Length of "+"Hello World is :"+s1);

	}

}
