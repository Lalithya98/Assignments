
public class JoinString {

	public static void main(String[] args) {
	
		String str ="Hello";
		System.out.println("Original String :"+str);
		  String str1=str.concat(" How Are You");
		  System.out.println("Updated String :"+str1);

	}

}
