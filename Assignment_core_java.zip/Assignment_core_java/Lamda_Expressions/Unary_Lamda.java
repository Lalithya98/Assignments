package Lamda_Expressions;

public class Unary_Lamda {
public static void main(String[] args) {
	UnaryOperator<Boolean> op=new UnaryO
}
}
